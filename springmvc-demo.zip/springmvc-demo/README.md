# SpringMVC 工具集合 - 项目部署指南

## 📋 项目概述

本项目是一个基于Spring MVC的工具集合，包含三个主要工具：
- **计算器工具** - 提供数学运算功能
- **字符串工具** - 提供字符串处理功能
- **日期时间工具** - 提供日期时间处理功能

所有工具都通过RESTful API暴露，支持通过HTTP请求访问。

## 🔧 环境要求

### 已配置环境
- **JDK**: 17
- **Maven**: 3.9.10
- **IDEA**: 2024.1
- **Tomcat**: 9.0
- **服务端口**: 8087

### 依赖版本
- Spring MVC: 5.3.23
- Jackson: 2.13.4
- Servlet API: 4.0.1
- JSP API: 2.3.3

## 🚀 项目结构

```
springmvc-demo/
├── pom.xml                           # Maven配置文件
├── README.md                         # 项目文档
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── example/
│       │           ├── tools/                    # 工具类
│       │           │   ├── CalculatorTool.java  # 计算器工具
│       │           │   ├── StringTool.java      # 字符串工具
│       │           │   └── DateTimeTool.java    # 日期时间工具
│       │           └── controller/               # 控制器
│       │               ├── CalculatorController.java
│       │               ├── StringController.java
│       │               ├── DateTimeController.java
│       │               └── MainController.java
│       ├── resources/
│       │   └── spring-mvc.xml        # Spring MVC配置
│       └── webapp/
│           └── WEB-INF/
│               ├── web.xml            # Web应用配置
│               └── views/
│                   └── index.jsp      # 主页面
```

## 📖 详细操作步骤

### 1. 环境准备

#### 1.1 验证JDK版本
```bash
java -version
```
应该显示：`openjdk version "17.x.x"`

#### 1.2 验证Maven版本
```bash
mvn -version
```
应该显示：`Apache Maven 3.9.10`

#### 1.3 验证Tomcat安装
确保Tomcat 9.0已正确安装在您的系统中。

### 2. 项目导入（使用IDEA）

#### 2.1 打开IDEA 2024.1
1. 启动 IntelliJ IDEA 2024.1
2. 选择 `File` → `Open`
3. 导航到项目目录：`D:\github\springmvc-demo`
4. 选择 `pom.xml` 文件
5. 点击 `Open as Project`

#### 2.2 项目同步
1. IDEA会自动识别Maven项目
2. 等待Maven依赖下载完成
3. 确保项目结构正确加载

### 3. 项目编译

#### 3.1 通过IDEA编译
1. 在IDEA中：`Build` → `Build Project`
2. 或使用快捷键：`Ctrl + F9`

#### 3.2 通过Maven命令编译
```bash
# 在项目根目录下执行
mvn clean compile
```

### 4. 项目部署

#### 4.1 方式一：使用IDEA内置Tomcat

1. **配置Tomcat服务器**
   - 点击 `Run` → `Edit Configurations`
   - 点击 `+` → `Tomcat Server` → `Local`
   - 配置Tomcat Home路径
   - 设置端口为：`8087`

2. **部署项目**
   - 在 `Deployment` 标签中点击 `+`
   - 选择 `Artifact` → `springmvc-demo:war exploded`
   - 设置 `Application context` 为 `/`

3. **启动服务**
   - 点击 `Run` 或 `Debug`
   - 等待服务启动完成

#### 4.2 方式二：使用Maven Tomcat插件

```bash
# 在项目根目录下执行
mvn tomcat7:run
```

#### 4.3 方式三：打包部署到外部Tomcat

1. **打包项目**
   ```bash
   mvn clean package
   ```

2. **部署WAR文件**
   - 将生成的 `target/springmvc-demo-1.0-SNAPSHOT.war` 复制到 Tomcat 的 `webapps` 目录
   - 启动Tomcat服务器

### 5. 验证部署

#### 5.1 访问主页
打开浏览器，访问：`http://localhost:8087`
- 应该看到工具集合的主页
- 页面显示所有可用的API接口

#### 5.2 测试API接口

**GET请求测试**（可直接在浏览器中访问）：
```
http://localhost:8087/api/health
http://localhost:8087/api/datetime/now
http://localhost:8087/api/calculator/functions
```

**POST请求测试**（需要使用Postman或其他工具）：
```
POST http://localhost:8087/api/calculator/add
Body: a=5&b=3

POST http://localhost:8087/api/string/reverse
Body: input=hello

POST http://localhost:8087/api/datetime/add-days
Body: date=2024-01-01&days=30
```

## 🛠️ 使用Postman测试

### 1. 安装Postman
从官网下载并安装Postman

### 2. 导入测试集合
可以手动创建以下测试请求：

#### 2.1 健康检查
```
GET http://localhost:8087/api/health
```

#### 2.2 计算器API测试
```
POST http://localhost:8087/api/calculator/add
Content-Type: application/x-www-form-urlencoded
Body: a=10&b=5

POST http://localhost:8087/api/calculator/divide
Content-Type: application/x-www-form-urlencoded
Body: a=20&b=4
```

#### 2.3 字符串API测试
```
POST http://localhost:8087/api/string/reverse
Content-Type: application/x-www-form-urlencoded
Body: input=SpringMVC

POST http://localhost:8087/api/string/is-palindrome
Content-Type: application/x-www-form-urlencoded
Body: input=level
```

#### 2.4 日期时间API测试
```
GET http://localhost:8087/api/datetime/now

POST http://localhost:8087/api/datetime/days-between
Content-Type: application/x-www-form-urlencoded
Body: startDate=2024-01-01&endDate=2024-12-31
```

## 📊 API 接口完整列表

### 计算器工具 (/api/calculator)
- `GET /functions` - 获取功能列表
- `POST /add` - 加法 (参数: a, b)
- `POST /subtract` - 减法 (参数: a, b)
- `POST /multiply` - 乘法 (参数: a, b)
- `POST /divide` - 除法 (参数: a, b)
- `POST /power` - 幂运算 (参数: base, exponent)
- `POST /sqrt` - 平方根 (参数: number)
- `POST /abs` - 绝对值 (参数: number)
- `POST /circle-area` - 圆面积 (参数: radius)

### 字符串工具 (/api/string)
- `GET /functions` - 获取功能列表
- `POST /reverse` - 反转 (参数: input)
- `POST /uppercase` - 转大写 (参数: input)
- `POST /lowercase` - 转小写 (参数: input)
- `POST /length` - 获取长度 (参数: input)
- `POST /is-palindrome` - 判断回文 (参数: input)
- `POST /trim` - 去除空格 (参数: input)
- `POST /split` - 分割 (参数: input, delimiter)

### 日期时间工具 (/api/datetime)
- `GET /functions` - 获取功能列表
- `GET /now` - 获取当前日期时间
- `GET /today` - 获取当前日期
- `POST /format` - 格式化日期 (参数: dateTime, format)
- `POST /days-between` - 计算日期差 (参数: startDate, endDate)
- `POST /add-days` - 添加天数 (参数: date, days)
- `POST /add-months` - 添加月数 (参数: date, months)
- `POST /add-years` - 添加年数 (参数: date, years)
- `POST /day-of-week` - 获取星期几 (参数: date)
- `POST /is-leap-year` - 判断闰年 (参数: year)
- `GET /timestamp` - 获取时间戳
- `POST /timestamp-to-date` - 时间戳转日期 (参数: timestamp)

### 系统信息 (/api)
- `GET /all-functions` - 获取所有API信息
- `GET /health` - 健康检查

## 🔧 故障排除

### 1. 编译错误
- 确保JDK版本为17
- 检查Maven配置是否正确
- 运行 `mvn clean compile` 重新编译

### 2. 端口冲突
- 确保端口8087未被占用
- 可以在 `pom.xml` 中修改端口配置

### 3. 404错误
- 检查Tomcat是否正确启动
- 确认项目部署路径正确
- 检查URL路径是否正确

### 4. 500错误
- 查看Tomcat日志文件
- 检查Spring配置文件
- 确认所有依赖都正确加载

## 📝 注意事项

1. **确保端口可用**：启动前请确保8087端口未被占用
2. **字符编码**：项目使用UTF-8编码，确保IDEA设置正确
3. **日期格式**：日期参数格式为 `yyyy-MM-dd`
4. **POST请求**：使用 `application/x-www-form-urlencoded` 格式发送参数
5. **异常处理**：所有API都包含错误处理，会返回详细的错误信息

## 🎯 成功标志

当您看到以下内容时，说明项目部署成功：

1. **浏览器访问** `http://localhost:8087` 显示工具集合主页
2. **API测试**：
   - `GET http://localhost:8087/api/health` 返回 `{"status":"UP"}`
   - `GET http://localhost:8087/api/datetime/now` 返回当前时间
   - `POST http://localhost:8087/api/calculator/add` 正常计算

## 📞 支持

如果遇到问题，请检查：
1. 所有环境配置是否正确
2. 项目是否正确编译
3. Tomcat服务器是否正常启动
4. 端口是否可用

祝您使用愉快！🎉 