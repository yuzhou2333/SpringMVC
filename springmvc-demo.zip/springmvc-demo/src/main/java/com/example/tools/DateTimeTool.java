package com.example.tools;

import org.springframework.stereotype.Component;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

/**
 * 日期时间工具类
 */
@Component
public class DateTimeTool {
    
    /**
     * 获取当前日期时间
     * @return 格式化的当前日期时间
     */
    public String getCurrentDateTime() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
    
    /**
     * 获取当前日期
     * @return 格式化的当前日期
     */
    public String getCurrentDate() {
        return LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }
    
    /**
     * 格式化日期
     * @param dateTime 日期时间字符串
     * @param format 目标格式
     * @return 格式化后的日期字符串
     */
    public String formatDate(String dateTime, String format) {
        try {
            LocalDateTime dt = LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            return dt.format(DateTimeFormatter.ofPattern(format));
        } catch (Exception e) {
            return "日期格式错误";
        }
    }
    
    /**
     * 计算两个日期之间的天数差
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 天数差
     */
    public long daysBetween(String startDate, String endDate) {
        try {
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);
            return ChronoUnit.DAYS.between(start, end);
        } catch (Exception e) {
            return 0;
        }
    }
    
    /**
     * 给日期添加天数
     * @param date 原始日期
     * @param days 要添加的天数
     * @return 新的日期
     */
    public String addDays(String date, int days) {
        try {
            LocalDate localDate = LocalDate.parse(date);
            return localDate.plusDays(days).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (Exception e) {
            return "日期格式错误";
        }
    }
    
    /**
     * 给日期添加月数
     * @param date 原始日期
     * @param months 要添加的月数
     * @return 新的日期
     */
    public String addMonths(String date, int months) {
        try {
            LocalDate localDate = LocalDate.parse(date);
            return localDate.plusMonths(months).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (Exception e) {
            return "日期格式错误";
        }
    }
    
    /**
     * 给日期添加年数
     * @param date 原始日期
     * @param years 要添加的年数
     * @return 新的日期
     */
    public String addYears(String date, int years) {
        try {
            LocalDate localDate = LocalDate.parse(date);
            return localDate.plusYears(years).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (Exception e) {
            return "日期格式错误";
        }
    }
    
    /**
     * 获取指定日期是星期几
     * @param date 日期
     * @return 星期几
     */
    public String getDayOfWeek(String date) {
        try {
            LocalDate localDate = LocalDate.parse(date);
            return localDate.getDayOfWeek().toString();
        } catch (Exception e) {
            return "日期格式错误";
        }
    }
    
    /**
     * 判断是否为闰年
     * @param year 年份
     * @return 是否为闰年
     */
    public boolean isLeapYear(int year) {
        return LocalDate.of(year, 1, 1).isLeapYear();
    }
    
    /**
     * 获取时间戳
     * @return 当前时间戳
     */
    public long getTimestamp() {
        return System.currentTimeMillis();
    }
    
    /**
     * 时间戳转日期
     * @param timestamp 时间戳
     * @return 格式化的日期字符串
     */
    public String timestampToDate(long timestamp) {
        return new Date(timestamp).toString();
    }
} 