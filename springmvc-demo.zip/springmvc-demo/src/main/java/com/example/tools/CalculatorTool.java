package com.example.tools;

import org.springframework.stereotype.Component;

/**
 * 计算器工具类
 */
@Component
public class CalculatorTool {
    
    /**
     * 加法运算
     * @param a 第一个数
     * @param b 第二个数
     * @return 相加结果
     */
    public double add(double a, double b) {
        return a + b;
    }
    
    /**
     * 减法运算
     * @param a 被减数
     * @param b 减数
     * @return 相减结果
     */
    public double subtract(double a, double b) {
        return a - b;
    }
    
    /**
     * 乘法运算
     * @param a 第一个数
     * @param b 第二个数
     * @return 相乘结果
     */
    public double multiply(double a, double b) {
        return a * b;
    }
    
    /**
     * 除法运算
     * @param a 被除数
     * @param b 除数
     * @return 相除结果
     * @throws IllegalArgumentException 除数为0时抛出异常
     */
    public double divide(double a, double b) {
        if (b == 0) {
            throw new IllegalArgumentException("除数不能为0");
        }
        return a / b;
    }
    
    /**
     * 求幂运算
     * @param base 底数
     * @param exponent 指数
     * @return 幂运算结果
     */
    public double power(double base, double exponent) {
        return Math.pow(base, exponent);
    }
    
    /**
     * 求平方根
     * @param number 输入数字
     * @return 平方根结果
     * @throws IllegalArgumentException 负数求平方根时抛出异常
     */
    public double sqrt(double number) {
        if (number < 0) {
            throw new IllegalArgumentException("负数不能求平方根");
        }
        return Math.sqrt(number);
    }
    
    /**
     * 求绝对值
     * @param number 输入数字
     * @return 绝对值
     */
    public double abs(double number) {
        return Math.abs(number);
    }
    
    /**
     * 求最大值
     * @param a 第一个数
     * @param b 第二个数
     * @return 最大值
     */
    public double max(double a, double b) {
        return Math.max(a, b);
    }
    
    /**
     * 求最小值
     * @param a 第一个数
     * @param b 第二个数
     * @return 最小值
     */
    public double min(double a, double b) {
        return Math.min(a, b);
    }
    
    /**
     * 四舍五入
     * @param number 输入数字
     * @param decimals 保留小数位数
     * @return 四舍五入结果
     */
    public double round(double number, int decimals) {
        double factor = Math.pow(10, decimals);
        return Math.round(number * factor) / factor;
    }
    
    /**
     * 计算圆面积
     * @param radius 半径
     * @return 圆面积
     */
    public double circleArea(double radius) {
        if (radius < 0) {
            throw new IllegalArgumentException("半径不能为负数");
        }
        return Math.PI * radius * radius;
    }
    
    /**
     * 计算圆周长
     * @param radius 半径
     * @return 圆周长
     */
    public double circlePerimeter(double radius) {
        if (radius < 0) {
            throw new IllegalArgumentException("半径不能为负数");
        }
        return 2 * Math.PI * radius;
    }
} 