package com.example.tools;

import org.springframework.stereotype.Component;

/**
 * 字符串处理工具类
 */
@Component
public class StringTool {
    
    /**
     * 字符串反转
     * @param input 输入字符串
     * @return 反转后的字符串
     */
    public String reverse(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return new StringBuilder(input).reverse().toString();
    }
    
    /**
     * 字符串转大写
     * @param input 输入字符串
     * @return 大写字符串
     */
    public String toUpperCase(String input) {
        if (input == null) {
            return null;
        }
        return input.toUpperCase();
    }
    
    /**
     * 字符串转小写
     * @param input 输入字符串
     * @return 小写字符串
     */
    public String toLowerCase(String input) {
        if (input == null) {
            return null;
        }
        return input.toLowerCase();
    }
    
    /**
     * 统计字符串长度
     * @param input 输入字符串
     * @return 字符串长度
     */
    public int getLength(String input) {
        if (input == null) {
            return 0;
        }
        return input.length();
    }
    
    /**
     * 判断是否为回文字符串
     * @param input 输入字符串
     * @return 是否为回文
     */
    public boolean isPalindrome(String input) {
        if (input == null || input.isEmpty()) {
            return true;
        }
        String cleaned = input.replaceAll("\\s+", "").toLowerCase();
        return cleaned.equals(new StringBuilder(cleaned).reverse().toString());
    }
    
    /**
     * 字符串去除空格
     * @param input 输入字符串
     * @return 去除空格后的字符串
     */
    public String trim(String input) {
        if (input == null) {
            return null;
        }
        return input.trim();
    }
    
    /**
     * 字符串分割
     * @param input 输入字符串
     * @param delimiter 分隔符
     * @return 分割后的数组
     */
    public String[] split(String input, String delimiter) {
        if (input == null || delimiter == null) {
            return new String[0];
        }
        return input.split(delimiter);
    }
} 