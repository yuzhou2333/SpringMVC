package com.example.controller;

import com.example.tools.CalculatorTool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

/**
 * 计算器控制器
 */
@RestController
@RequestMapping("/api/calculator")
public class CalculatorController {
    
    @Autowired
    private CalculatorTool calculatorTool;
    
    /**
     * 加法运算
     */
    @PostMapping("/add")
    public Map<String, Object> add(@RequestParam double a, @RequestParam double b) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.add(a, b);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", a + " + " + b + " = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 减法运算
     */
    @PostMapping("/subtract")
    public Map<String, Object> subtract(@RequestParam double a, @RequestParam double b) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.subtract(a, b);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", a + " - " + b + " = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 乘法运算
     */
    @PostMapping("/multiply")
    public Map<String, Object> multiply(@RequestParam double a, @RequestParam double b) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.multiply(a, b);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", a + " * " + b + " = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 除法运算
     */
    @PostMapping("/divide")
    public Map<String, Object> divide(@RequestParam double a, @RequestParam double b) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.divide(a, b);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", a + " / " + b + " = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 幂运算
     */
    @PostMapping("/power")
    public Map<String, Object> power(@RequestParam double base, @RequestParam double exponent) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.power(base, exponent);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", base + " ^ " + exponent + " = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 平方根运算
     */
    @PostMapping("/sqrt")
    public Map<String, Object> sqrt(@RequestParam double number) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.sqrt(number);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "√" + number + " = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 绝对值运算
     */
    @PostMapping("/abs")
    public Map<String, Object> abs(@RequestParam double number) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.abs(number);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "|" + number + "| = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 圆面积计算
     */
    @PostMapping("/circle-area")
    public Map<String, Object> circleArea(@RequestParam double radius) {
        Map<String, Object> result = new HashMap<>();
        try {
            double res = calculatorTool.circleArea(radius);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "圆面积 (半径=" + radius + ") = " + res);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取所有计算器功能
     */
    @GetMapping("/functions")
    public Map<String, Object> getFunctions() {
        Map<String, Object> result = new HashMap<>();
        result.put("functions", new String[]{
            "POST /api/calculator/add - 加法 (参数: a, b)",
            "POST /api/calculator/subtract - 减法 (参数: a, b)",
            "POST /api/calculator/multiply - 乘法 (参数: a, b)",
            "POST /api/calculator/divide - 除法 (参数: a, b)",
            "POST /api/calculator/power - 幂运算 (参数: base, exponent)",
            "POST /api/calculator/sqrt - 平方根 (参数: number)",
            "POST /api/calculator/abs - 绝对值 (参数: number)",
            "POST /api/calculator/circle-area - 圆面积 (参数: radius)"
        });
        return result;
    }
} 