package com.example.controller;

import com.example.tools.DateTimeTool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

/**
 * 日期时间工具控制器
 */
@RestController
@RequestMapping("/api/datetime")
public class DateTimeController {
    
    @Autowired
    private DateTimeTool dateTimeTool;
    
    /**
     * 获取当前日期时间
     */
    @GetMapping("/now")
    public Map<String, Object> getCurrentDateTime() {
        Map<String, Object> result = new HashMap<>();
        try {
            String dateTime = dateTimeTool.getCurrentDateTime();
            result.put("success", true);
            result.put("result", dateTime);
            result.put("operation", "获取当前日期时间");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取当前日期
     */
    @GetMapping("/today")
    public Map<String, Object> getCurrentDate() {
        Map<String, Object> result = new HashMap<>();
        try {
            String date = dateTimeTool.getCurrentDate();
            result.put("success", true);
            result.put("result", date);
            result.put("operation", "获取当前日期");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 格式化日期
     */
    @PostMapping("/format")
    public Map<String, Object> formatDate(@RequestParam String dateTime, @RequestParam String format) {
        Map<String, Object> result = new HashMap<>();
        try {
            String formatted = dateTimeTool.formatDate(dateTime, format);
            result.put("success", true);
            result.put("result", formatted);
            result.put("operation", "格式化日期 \"" + dateTime + "\" 为 \"" + format + "\" = \"" + formatted + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 计算两个日期之间的天数差
     */
    @PostMapping("/days-between")
    public Map<String, Object> daysBetween(@RequestParam String startDate, @RequestParam String endDate) {
        Map<String, Object> result = new HashMap<>();
        try {
            long days = dateTimeTool.daysBetween(startDate, endDate);
            result.put("success", true);
            result.put("result", days);
            result.put("operation", "从 \"" + startDate + "\" 到 \"" + endDate + "\" 相差 " + days + " 天");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 给日期添加天数
     */
    @PostMapping("/add-days")
    public Map<String, Object> addDays(@RequestParam String date, @RequestParam int days) {
        Map<String, Object> result = new HashMap<>();
        try {
            String newDate = dateTimeTool.addDays(date, days);
            result.put("success", true);
            result.put("result", newDate);
            result.put("operation", "日期 \"" + date + "\" 加 " + days + " 天 = \"" + newDate + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 给日期添加月数
     */
    @PostMapping("/add-months")
    public Map<String, Object> addMonths(@RequestParam String date, @RequestParam int months) {
        Map<String, Object> result = new HashMap<>();
        try {
            String newDate = dateTimeTool.addMonths(date, months);
            result.put("success", true);
            result.put("result", newDate);
            result.put("operation", "日期 \"" + date + "\" 加 " + months + " 个月 = \"" + newDate + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 给日期添加年数
     */
    @PostMapping("/add-years")
    public Map<String, Object> addYears(@RequestParam String date, @RequestParam int years) {
        Map<String, Object> result = new HashMap<>();
        try {
            String newDate = dateTimeTool.addYears(date, years);
            result.put("success", true);
            result.put("result", newDate);
            result.put("operation", "日期 \"" + date + "\" 加 " + years + " 年 = \"" + newDate + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取指定日期是星期几
     */
    @PostMapping("/day-of-week")
    public Map<String, Object> getDayOfWeek(@RequestParam String date) {
        Map<String, Object> result = new HashMap<>();
        try {
            String dayOfWeek = dateTimeTool.getDayOfWeek(date);
            result.put("success", true);
            result.put("result", dayOfWeek);
            result.put("operation", "日期 \"" + date + "\" 是 " + dayOfWeek);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 判断是否为闰年
     */
    @PostMapping("/is-leap-year")
    public Map<String, Object> isLeapYear(@RequestParam int year) {
        Map<String, Object> result = new HashMap<>();
        try {
            boolean isLeap = dateTimeTool.isLeapYear(year);
            result.put("success", true);
            result.put("result", isLeap);
            result.put("operation", year + "年是闰年: " + isLeap);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取时间戳
     */
    @GetMapping("/timestamp")
    public Map<String, Object> getTimestamp() {
        Map<String, Object> result = new HashMap<>();
        try {
            long timestamp = dateTimeTool.getTimestamp();
            result.put("success", true);
            result.put("result", timestamp);
            result.put("operation", "获取当前时间戳");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 时间戳转日期
     */
    @PostMapping("/timestamp-to-date")
    public Map<String, Object> timestampToDate(@RequestParam long timestamp) {
        Map<String, Object> result = new HashMap<>();
        try {
            String date = dateTimeTool.timestampToDate(timestamp);
            result.put("success", true);
            result.put("result", date);
            result.put("operation", "时间戳 " + timestamp + " 转换为日期 \"" + date + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取所有日期时间工具功能
     */
    @GetMapping("/functions")
    public Map<String, Object> getFunctions() {
        Map<String, Object> result = new HashMap<>();
        result.put("functions", new String[]{
            "GET /api/datetime/now - 获取当前日期时间",
            "GET /api/datetime/today - 获取当前日期",
            "POST /api/datetime/format - 格式化日期 (参数: dateTime, format)",
            "POST /api/datetime/days-between - 计算日期差 (参数: startDate, endDate)",
            "POST /api/datetime/add-days - 添加天数 (参数: date, days)",
            "POST /api/datetime/add-months - 添加月数 (参数: date, months)",
            "POST /api/datetime/add-years - 添加年数 (参数: date, years)",
            "POST /api/datetime/day-of-week - 获取星期几 (参数: date)",
            "POST /api/datetime/is-leap-year - 判断闰年 (参数: year)",
            "GET /api/datetime/timestamp - 获取时间戳",
            "POST /api/datetime/timestamp-to-date - 时间戳转日期 (参数: timestamp)"
        });
        return result;
    }
} 