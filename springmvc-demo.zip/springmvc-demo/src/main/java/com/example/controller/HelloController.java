package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
    
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String hello(Model model) {
        model.addAttribute("message", "Hello World");
        return "hello";
    }
    
    @RequestMapping(value = "/t2", method = RequestMethod.GET)
    public String t2(Model model) {
        model.addAttribute("message", "成功加载t2");
        return "t2";
    }
} 