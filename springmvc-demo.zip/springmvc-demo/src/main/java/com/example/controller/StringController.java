package com.example.controller;

import com.example.tools.StringTool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

/**
 * 字符串工具控制器
 */
@RestController
@RequestMapping("/api/string")
public class StringController {
    
    @Autowired
    private StringTool stringTool;
    
    /**
     * 字符串反转
     */
    @PostMapping("/reverse")
    public Map<String, Object> reverse(@RequestParam String input) {
        Map<String, Object> result = new HashMap<>();
        try {
            String res = stringTool.reverse(input);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "反转 \"" + input + "\" = \"" + res + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 字符串转大写
     */
    @PostMapping("/uppercase")
    public Map<String, Object> toUpperCase(@RequestParam String input) {
        Map<String, Object> result = new HashMap<>();
        try {
            String res = stringTool.toUpperCase(input);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "转大写 \"" + input + "\" = \"" + res + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 字符串转小写
     */
    @PostMapping("/lowercase")
    public Map<String, Object> toLowerCase(@RequestParam String input) {
        Map<String, Object> result = new HashMap<>();
        try {
            String res = stringTool.toLowerCase(input);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "转小写 \"" + input + "\" = \"" + res + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取字符串长度
     */
    @PostMapping("/length")
    public Map<String, Object> getLength(@RequestParam String input) {
        Map<String, Object> result = new HashMap<>();
        try {
            int length = stringTool.getLength(input);
            result.put("success", true);
            result.put("result", length);
            result.put("operation", "字符串 \"" + input + "\" 长度 = " + length);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 判断是否为回文字符串
     */
    @PostMapping("/is-palindrome")
    public Map<String, Object> isPalindrome(@RequestParam String input) {
        Map<String, Object> result = new HashMap<>();
        try {
            boolean isPalindrome = stringTool.isPalindrome(input);
            result.put("success", true);
            result.put("result", isPalindrome);
            result.put("operation", "字符串 \"" + input + "\" 是回文: " + isPalindrome);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 去除空格
     */
    @PostMapping("/trim")
    public Map<String, Object> trim(@RequestParam String input) {
        Map<String, Object> result = new HashMap<>();
        try {
            String res = stringTool.trim(input);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "去除空格 \"" + input + "\" = \"" + res + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 字符串分割
     */
    @PostMapping("/split")
    public Map<String, Object> split(@RequestParam String input, @RequestParam String delimiter) {
        Map<String, Object> result = new HashMap<>();
        try {
            String[] parts = stringTool.split(input, delimiter);
            result.put("success", true);
            result.put("result", parts);
            result.put("operation", "分割 \"" + input + "\" 用分隔符 \"" + delimiter + "\" = " + parts.length + " 个部分");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取所有字符串工具功能
     */
    @GetMapping("/functions")
    public Map<String, Object> getFunctions() {
        Map<String, Object> result = new HashMap<>();
        result.put("functions", new String[]{
            "POST /api/string/reverse - 字符串反转 (参数: input)",
            "POST /api/string/uppercase - 转大写 (参数: input)",
            "POST /api/string/lowercase - 转小写 (参数: input)",
            "POST /api/string/length - 获取长度 (参数: input)",
            "POST /api/string/is-palindrome - 判断回文 (参数: input)",
            "POST /api/string/trim - 去除空格 (参数: input)",
            "POST /api/string/split - 字符串分割 (参数: input, delimiter)"
        });
        return result;
    }
} 