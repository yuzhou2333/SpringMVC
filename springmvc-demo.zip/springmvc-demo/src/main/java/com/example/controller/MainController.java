package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

/**
 * 主控制器 - 提供API汇总信息
 */
@RestController
@RequestMapping("/api")
public class MainController {
    
    /**
     * 获取所有可用的API接口
     */
    @GetMapping("/all-functions")
    public Map<String, Object> getAllFunctions() {
        Map<String, Object> result = new HashMap<>();
        
        // 计算器工具API
        result.put("calculator", new String[]{
            "GET /api/calculator/functions - 获取计算器功能列表",
            "POST /api/calculator/add - 加法 (参数: a, b)",
            "POST /api/calculator/subtract - 减法 (参数: a, b)",
            "POST /api/calculator/multiply - 乘法 (参数: a, b)",
            "POST /api/calculator/divide - 除法 (参数: a, b)",
            "POST /api/calculator/power - 幂运算 (参数: base, exponent)",
            "POST /api/calculator/sqrt - 平方根 (参数: number)",
            "POST /api/calculator/abs - 绝对值 (参数: number)",
            "POST /api/calculator/circle-area - 圆面积 (参数: radius)"
        });
        
        // 字符串工具API
        result.put("string", new String[]{
            "GET /api/string/functions - 获取字符串功能列表",
            "POST /api/string/reverse - 字符串反转 (参数: input)",
            "POST /api/string/uppercase - 转大写 (参数: input)",
            "POST /api/string/lowercase - 转小写 (参数: input)",
            "POST /api/string/length - 获取长度 (参数: input)",
            "POST /api/string/is-palindrome - 判断回文 (参数: input)",
            "POST /api/string/trim - 去除空格 (参数: input)",
            "POST /api/string/split - 字符串分割 (参数: input, delimiter)"
        });
        
        // 日期时间工具API
        result.put("datetime", new String[]{
            "GET /api/datetime/functions - 获取日期时间功能列表",
            "GET /api/datetime/now - 获取当前日期时间",
            "GET /api/datetime/today - 获取当前日期",
            "POST /api/datetime/format - 格式化日期 (参数: dateTime, format)",
            "POST /api/datetime/days-between - 计算日期差 (参数: startDate, endDate)",
            "POST /api/datetime/add-days - 添加天数 (参数: date, days)",
            "POST /api/datetime/add-months - 添加月数 (参数: date, months)",
            "POST /api/datetime/add-years - 添加年数 (参数: date, years)",
            "POST /api/datetime/day-of-week - 获取星期几 (参数: date)",
            "POST /api/datetime/is-leap-year - 判断闰年 (参数: year)",
            "GET /api/datetime/timestamp - 获取时间戳",
            "POST /api/datetime/timestamp-to-date - 时间戳转日期 (参数: timestamp)"
        });
        
        result.put("message", "SpringMVC 工具集合 - 所有API接口可用");
        result.put("version", "1.0.0");
        
        return result;
    }
    
    /**
     * 健康检查接口
     */
    @GetMapping("/health")
    public Map<String, Object> healthCheck() {
        Map<String, Object> result = new HashMap<>();
        result.put("status", "UP");
        result.put("message", "SpringMVC 工具服务正常运行");
        result.put("timestamp", System.currentTimeMillis());
        return result;
    }
}

/**
 * 页面控制器 - 提供主页
 */
@Controller
class HomeController {
    
    @GetMapping("/")
    public String home() {
        return "index";
    }
} 