# SpringMVC 工具集合 - 开发指南

## 📋 文档目标

本指南旨在帮助开发者理解项目的代码结构、注解含义，以及如何添加新的工具类和API接口。

## 🏗️ 项目架构解析

### 1. 整体架构模式

项目采用经典的 **MVC (Model-View-Controller)** 架构：

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Controller    │───▶│      Tool       │───▶│      View       │
│   (控制层)       │    │    (业务层)      │    │    (视图层)      │
│                 │    │                 │    │                 │
│ - 接收HTTP请求   │    │ - 具体业务逻辑   │    │ - JSON响应      │
│ - 参数验证      │    │ - 数据处理      │    │ - JSP页面       │
│ - 调用工具类     │    │ - 异常处理      │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### 2. 包结构详解

```
com.example/
├── tools/          # 业务工具类 (Model层)
│   ├── CalculatorTool.java
│   ├── StringTool.java
│   └── DateTimeTool.java
└── controller/     # 控制器类 (Controller层)
    ├── CalculatorController.java
    ├── StringController.java
    ├── DateTimeController.java
    └── MainController.java
```

## 🔧 工具类详解

### 1. 工具类的基本结构

每个工具类都遵循相同的模式：

```java
package com.example.tools;

import org.springframework.stereotype.Component;  // ← 重要注解

/**
 * 工具类说明
 */
@Component  // ← 这个注解告诉Spring这是一个组件
public class YourTool {
    
    /**
     * 方法说明
     * @param input 参数说明
     * @return 返回值说明
     */
    public ReturnType methodName(ParameterType input) {
        // 业务逻辑
        return result;
    }
}
```

#### 关键注解说明：

- `@Component`：
  - **作用**：标记这个类为Spring管理的组件
  - **必须性**：必须添加，否则Controller无法注入使用
  - **位置**：类定义前
  - **示例**：`@Component`

### 2. 现有工具类分析

#### 2.1 CalculatorTool.java - 计算器工具

**核心方法类型**：
```java
// 基础运算方法
public double add(double a, double b)           // 加法
public double subtract(double a, double b)      // 减法
public double multiply(double a, double b)      // 乘法
public double divide(double a, double b)        // 除法

// 高级运算方法  
public double power(double base, double exponent) // 幂运算
public double sqrt(double number)               // 平方根
public double abs(double number)                // 绝对值

// 几何计算方法
public double circleArea(double radius)         // 圆面积
public double circlePerimeter(double radius)    // 圆周长
```

**异常处理模式**：
```java
public double divide(double a, double b) {
    if (b == 0) {
        throw new IllegalArgumentException("除数不能为0");  // ← 参数验证
    }
    return a / b;
}
```

#### 2.2 StringTool.java - 字符串工具

**核心方法类型**：
```java
// 字符串转换方法
public String reverse(String input)            // 反转
public String toUpperCase(String input)        // 转大写
public String toLowerCase(String input)        // 转小写
public String trim(String input)               // 去除空格

// 字符串分析方法
public int getLength(String input)             // 获取长度
public boolean isPalindrome(String input)      // 判断回文
public String[] split(String input, String delimiter) // 分割
```

**空值处理模式**：
```java
public String reverse(String input) {
    if (input == null || input.isEmpty()) {
        return input;  // ← 安全的空值处理
    }
    return new StringBuilder(input).reverse().toString();
}
```

#### 2.3 DateTimeTool.java - 日期时间工具

**核心方法类型**：
```java
// 日期获取方法
public String getCurrentDateTime()              // 当前日期时间
public String getCurrentDate()                 // 当前日期
public long getTimestamp()                     // 时间戳

// 日期计算方法
public long daysBetween(String start, String end)    // 计算天数差
public String addDays(String date, int days)         // 添加天数
public String addMonths(String date, int months)     // 添加月数
public String addYears(String date, int years)       // 添加年数

// 日期分析方法
public String formatDate(String dateTime, String format) // 格式化
public String getDayOfWeek(String date)               // 获取星期
public boolean isLeapYear(int year)                   // 判断闰年
```

**日期处理模式**：
```java
public String addDays(String date, int days) {
    try {
        LocalDate localDate = LocalDate.parse(date);
        return localDate.plusDays(days).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    } catch (Exception e) {
        return "日期格式错误";  // ← 统一的错误处理
    }
}
```

## 🎮 控制器详解

### 1. 控制器的基本结构

```java
package com.example.controller;

import com.example.tools.YourTool;              // ← 导入工具类
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

/**
 * 控制器说明
 */
@RestController                                 // ← 标记为REST控制器
@RequestMapping("/api/yourtool")               // ← 设置基础路径
public class YourController {
    
    @Autowired                                 // ← 自动注入工具类
    private YourTool yourTool;
    
    @PostMapping("/method")                    // ← 定义POST接口
    public Map<String, Object> method(@RequestParam String param) {
        // 控制器逻辑
    }
}
```

### 2. 关键注解详解

#### 2.1 类级别注解

```java
@RestController
// 作用：标记这是一个REST风格的控制器
// 效果：所有方法返回的对象会自动转换为JSON
// 必须性：必须添加

@RequestMapping("/api/calculator")
// 作用：设置控制器的基础URL路径
// 效果：所有方法的URL都会以此为前缀
// 必须性：推荐添加，便于API管理
```

#### 2.2 字段注解

```java
@Autowired
private CalculatorTool calculatorTool;
// 作用：自动注入Spring管理的组件
// 效果：Spring会自动创建工具类实例并注入
// 必须性：必须添加，否则工具类为null
```

#### 2.3 方法注解

```java
@PostMapping("/add")
// 作用：映射POST请求到此方法
// 路径：/api/calculator/add (基础路径 + 方法路径)
// 替代方案：@GetMapping、@PutMapping、@DeleteMapping

@RequestParam double a
// 作用：从HTTP请求参数中获取值
// 格式：form-data 或 x-www-form-urlencoded
// 必须性：参数必须提供，否则400错误
```

### 3. 标准响应格式

```java
public Map<String, Object> add(@RequestParam double a, @RequestParam double b) {
    Map<String, Object> result = new HashMap<>();
    try {
        double res = calculatorTool.add(a, b);
        result.put("success", true);                    // ← 成功标志
        result.put("result", res);                      // ← 实际结果
        result.put("operation", a + " + " + b + " = " + res); // ← 操作描述
    } catch (Exception e) {
        result.put("success", false);                   // ← 失败标志
        result.put("error", e.getMessage());            // ← 错误信息
    }
    return result;
}
```

**响应JSON示例**：
```json
// 成功响应
{
    "success": true,
    "result": 8.0,
    "operation": "5.0 + 3.0 = 8.0"
}

// 错误响应
{
    "success": false,
    "error": "除数不能为0"
}
```

## 🔄 添加新工具的完整流程

### 步骤1：创建工具类

**文件位置**：`src/main/java/com/example/tools/NewTool.java`

```java
package com.example.tools;

import org.springframework.stereotype.Component;

/**
 * 新工具类说明
 */
@Component  // ← 必须添加这个注解
public class NewTool {
    
    /**
     * 工具方法
     * @param input 输入参数
     * @return 处理结果
     */
    public String processMethod(String input) {
        // 1. 参数验证
        if (input == null || input.trim().isEmpty()) {
            throw new IllegalArgumentException("输入不能为空");
        }
        
        // 2. 业务逻辑
        String result = input.toUpperCase();
        
        // 3. 返回结果
        return result;
    }
    
    // 添加更多方法...
}
```

### 步骤2：创建控制器

**文件位置**：`src/main/java/com/example/controller/NewController.java`

```java
package com.example.controller;

import com.example.tools.NewTool;  // ← 导入新工具类
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

/**
 * 新工具控制器
 */
@RestController  // ← 必须添加
@RequestMapping("/api/newtool")  // ← 设置API路径
public class NewController {
    
    @Autowired  // ← 必须添加
    private NewTool newTool;  // ← 注入工具类
    
    /**
     * 处理方法
     */
    @PostMapping("/process")  // ← 定义接口路径
    public Map<String, Object> process(@RequestParam String input) {
        Map<String, Object> result = new HashMap<>();
        try {
            String res = newTool.processMethod(input);
            result.put("success", true);
            result.put("result", res);
            result.put("operation", "处理 \"" + input + "\" = \"" + res + "\"");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    /**
     * 获取功能列表
     */
    @GetMapping("/functions")
    public Map<String, Object> getFunctions() {
        Map<String, Object> result = new HashMap<>();
        result.put("functions", new String[]{
            "POST /api/newtool/process - 处理方法 (参数: input)"
        });
        return result;
    }
}
```

### 步骤3：更新主控制器

**文件位置**：`src/main/java/com/example/controller/MainController.java`

在`getAllFunctions()`方法中添加新工具的API信息：

```java
@GetMapping("/all-functions")
public Map<String, Object> getAllFunctions() {
    Map<String, Object> result = new HashMap<>();
    
    // ... 现有工具 ...
    
    // 新工具API  ← 添加这部分
    result.put("newtool", new String[]{
        "GET /api/newtool/functions - 获取新工具功能列表",
        "POST /api/newtool/process - 处理方法 (参数: input)"
    });
    
    // ... 其他代码 ...
}
```

### 步骤4：更新主页面

**文件位置**：`src/main/webapp/WEB-INF/views/index.jsp`

在适当位置添加新工具的API说明：

```html
<div class="tool-section">
    <h2>🆕 新工具 (NewTool)</h2>
    <ul class="api-list">
        <li class="api-item method-get">
            <span class="method">GET</span> <span class="endpoint">/api/newtool/functions</span>
            <div class="description">获取新工具功能列表</div>
        </li>
        <li class="api-item method-post">
            <span class="method">POST</span> <span class="endpoint">/api/newtool/process</span>
            <div class="description">处理方法 (参数: input)</div>
        </li>
    </ul>
</div>
```

## 📝 代码规范和最佳实践

### 1. 工具类开发规范

#### 命名规范
```java
// 类名：工具类以Tool结尾
public class CalculatorTool  ✅
public class Calculator      ❌

// 方法名：使用动词开头，驼峰命名
public String formatDate()   ✅
public String date_format()  ❌

// 参数名：有意义的名称
public double add(double a, double b)        ✅
public double add(double x, double y)        ❌
public double add(double firstNumber, double secondNumber) ✅
```

#### 异常处理规范
```java
// 推荐：抛出有意义的异常
if (input == null) {
    throw new IllegalArgumentException("输入参数不能为null");
}

// 避免：返回特殊值
if (input == null) {
    return -1;  // ❌ 不清晰
}
```

#### 注释规范
```java
/**
 * 计算圆的面积
 * @param radius 圆的半径，必须大于0
 * @return 圆的面积值
 * @throws IllegalArgumentException 当半径小于或等于0时抛出
 */
public double circleArea(double radius) {
    // 方法实现
}
```

### 2. 控制器开发规范

#### 路径规范
```java
// 推荐：RESTful风格
@RequestMapping("/api/calculator")    // 资源名词
@PostMapping("/add")                  // 动作动词

// 避免：混乱的命名
@RequestMapping("/calc")              // ❌ 缩写不清晰
@PostMapping("/doAdd")                // ❌ 不符合REST风格
```

#### 参数验证
```java
@PostMapping("/divide")
public Map<String, Object> divide(@RequestParam double a, @RequestParam double b) {
    Map<String, Object> result = new HashMap<>();
    try {
        // 在调用工具类前可以添加额外验证
        if (Double.isNaN(a) || Double.isNaN(b)) {
            throw new IllegalArgumentException("参数必须是有效数字");
        }
        
        double res = calculatorTool.divide(a, b);
        // ... 成功处理
    } catch (Exception e) {
        // ... 错误处理
    }
    return result;
}
```

### 3. 错误处理最佳实践

#### 工具类中的错误处理
```java
public String formatDate(String dateTime, String format) {
    try {
        LocalDateTime dt = LocalDateTime.parse(dateTime, 
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        return dt.format(DateTimeFormatter.ofPattern(format));
    } catch (DateTimeParseException e) {
        return "日期格式错误：" + e.getMessage();  // ← 提供具体错误信息
    } catch (IllegalArgumentException e) {
        return "格式字符串错误：" + e.getMessage();
    } catch (Exception e) {
        return "未知错误：" + e.getMessage();
    }
}
```

#### 控制器中的错误处理
```java
@PostMapping("/format")
public Map<String, Object> formatDate(@RequestParam String dateTime, 
                                     @RequestParam String format) {
    Map<String, Object> result = new HashMap<>();
    try {
        String formatted = dateTimeTool.formatDate(dateTime, format);
        
        // 检查工具类是否返回了错误信息
        if (formatted.contains("错误")) {
            result.put("success", false);
            result.put("error", formatted);
        } else {
            result.put("success", true);
            result.put("result", formatted);
            result.put("operation", "格式化日期成功");
        }
    } catch (Exception e) {
        result.put("success", false);
        result.put("error", "服务器内部错误：" + e.getMessage());
    }
    return result;
}
```

## 🧪 测试和调试

### 1. 单元测试工具方法

```java
// 在工具类中添加测试用的main方法（开发阶段）
public static void main(String[] args) {
    CalculatorTool tool = new CalculatorTool();
    
    // 测试正常情况
    System.out.println("5 + 3 = " + tool.add(5, 3));
    
    // 测试异常情况
    try {
        tool.divide(10, 0);
    } catch (Exception e) {
        System.out.println("异常测试成功：" + e.getMessage());
    }
}
```

### 2. 使用日志输出

```java
// 在方法中添加日志（可选）
public double divide(double a, double b) {
    System.out.println("计算 " + a + " ÷ " + b);  // 调试信息
    
    if (b == 0) {
        System.out.println("错误：除数为0");  // 错误日志
        throw new IllegalArgumentException("除数不能为0");
    }
    
    double result = a / b;
    System.out.println("结果：" + result);  // 结果日志
    return result;
}
```

## 🔍 常见问题和解决方案

### 1. 工具类无法注入（NullPointerException）

**症状**：控制器中工具类为null

**原因**：
- 忘记添加`@Component`注解
- 包扫描路径不正确

**解决方案**：
```java
// 确保工具类有@Component注解
@Component  // ← 必须添加
public class YourTool {
    // ...
}

// 确保spring-mvc.xml中的包扫描包含工具类
<context:component-scan base-package="com.example" />
```

### 2. 404错误 - 接口无法访问

**症状**：访问API返回404

**原因**：
- URL路径错误
- 控制器注解错误
- HTTP方法不匹配

**解决方案**：
```java
// 检查注解配置
@RestController  // ← 必须是RestController
@RequestMapping("/api/calculator")  // ← 检查路径
public class CalculatorController {
    
    @PostMapping("/add")  // ← 确保HTTP方法正确
    public Map<String, Object> add(...) {
        // ...
    }
}

// 确保访问的URL正确
// 正确：POST http://localhost:8087/api/calculator/add
// 错误：GET http://localhost:8087/api/calculator/add
```

### 3. 400错误 - 参数错误

**症状**：传递参数但返回400

**原因**：
- 参数名不匹配
- 参数类型不匹配
- 缺少必需参数

**解决方案**：
```java
// 确保参数名匹配
@RequestParam double a  // ← 参数名必须是'a'

// 在Postman中发送请求时：
// Body类型：x-www-form-urlencoded
// Key: a, Value: 5
// Key: b, Value: 3
```

### 4. 500错误 - 服务器内部错误

**症状**：请求处理时服务器崩溃

**原因**：
- 工具类方法抛出未捕获异常
- 空指针异常
- 类型转换错误

**解决方案**：
```java
// 在控制器中添加完善的异常处理
@PostMapping("/method")
public Map<String, Object> method(@RequestParam String input) {
    Map<String, Object> result = new HashMap<>();
    try {
        // 调用工具类方法
        String res = tool.process(input);
        result.put("success", true);
        result.put("result", res);
    } catch (IllegalArgumentException e) {
        result.put("success", false);
        result.put("error", "参数错误：" + e.getMessage());
    } catch (Exception e) {
        result.put("success", false);
        result.put("error", "服务器错误：" + e.getMessage());
    }
    return result;
}
```

## 📚 扩展学习建议

### 1. Spring注解深入学习

- `@Component` vs `@Service` vs `@Repository`
- `@Autowired` vs `@Resource` vs `@Inject`
- `@RequestMapping` 的高级用法

### 2. REST API设计原则

- HTTP状态码的正确使用
- RESTful URL设计规范
- API版本控制

### 3. 异常处理机制

- 全局异常处理器 `@ControllerAdvice`
- 自定义异常类
- 统一响应格式

### 4. 数据验证

- `@Valid` 注解使用
- 自定义验证器
- 参数绑定和转换

---

希望这份指南能帮助您和您的团队更好地理解和扩展这个SpringMVC工具集合项目！如果有任何问题，请随时询问。 